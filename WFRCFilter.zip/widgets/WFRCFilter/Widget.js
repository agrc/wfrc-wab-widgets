define(['dojo/_base/declare', 'jimu/BaseWidget', './Filter/Filter'], function (declare, BaseWidget, Filter) {
  return declare([BaseWidget], {
    mainWidget: null,
    postCreate: function postCreate() {
      this.mainWidget = new Filter({
        config: this.config,
        map: this.map
      }, this.widgetContainer);
      this.mainWidget.init();
    }
  });
});
//# sourceMappingURL=Widget.js.map
