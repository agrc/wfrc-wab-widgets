define(['dijit/_TemplatedMixin', 'dijit/_WidgetBase', 'dojo/_base/declare', 'dojo/text!./Filter.html'], function (_TemplatedMixin, _WidgetBase, declare, template) {
  function _toConsumableArray(arr) {
    return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread();
  }

  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance");
  }

  function _iterableToArray(iter) {
    if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter);
  }

  function _arrayWithoutHoles(arr) {
    if (Array.isArray(arr)) {
      for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) {
        arr2[i] = arr[i];
      }

      return arr2;
    }
  }

  var landUseLayers = ['centers', 'generalLandUse'];
  return declare([_WidgetBase, _TemplatedMixin], {
    baseClass: 'wfrc-filter',
    templateString: template,
    postMixInProperties: function postMixInProperties() {
      console.log('Filter.postMixInProperties');
      this.nls = this.config.strings[this.config.language];
    },
    postCreate: function postCreate() {
      console.log('Filter.postCreate');
      this.modes.indeterminate = true;
      this.phasing.indeterminate = true;
    },
    init: function init() {
      var _this = this;

      console.log('Filter.init');
      this.setupParentChildCheckboxes();
      var layers = this.getLayers(this.config.layerNames, this.map); // modes

      this.modes = {
        roads: [layers.roadwayPointProjects, layers.roadwayLineProjects, layers.magRoadwayLineProjects, layers.magPointProjects],
        transit: [layers.transitPointProjects, layers.transitLineProjects, layers.magTransitLineProjects],
        bikeped: [layers.activeTransportationPointProjects, layers.activeTransportationLineProjects]
      };

      var onModeCheckboxChange = function onModeCheckboxChange(mode) {
        _this.modes[mode].forEach(function (layer) {
          return layer.setVisibility(_this[mode].checked);
        });
      };

      Object.keys(this.modes).forEach(function (mode) {
        var checkbox = _this[mode];
        checkbox.addEventListener('change', onModeCheckboxChange.bind(_this, [mode]));
      }); // phases

      var phaseCheckboxes = Array.from(this.domNode.getElementsByClassName('phasing-checkbox'));

      var onPhaseCheckboxChange = function onPhaseCheckboxChange() {
        var checkedPhaseIndexes = phaseCheckboxes.filter(function (box) {
          return box.checked;
        }).map(function (box) {
          return parseInt(box.value, 10);
        });
        Object.keys(_this.config.phases).forEach(function (phaseLayerKey) {
          // apply phasing filter to land use layers only if the byPhasing checkbox is checked
          if (landUseLayers.indexOf(phaseLayerKey) > -1 && !_this.byPhasing.checked) {
            return;
          }

          var info = _this.config.phases[phaseLayerKey];
          layers[phaseLayerKey].setDefinitionExpression(_this.getPhaseQuery(info, checkedPhaseIndexes));
        });
      };

      phaseCheckboxes.forEach(function (checkbox) {
        checkbox.addEventListener('change', onPhaseCheckboxChange);
      }); // make map layers reflect initial state of filter controls

      onPhaseCheckboxChange();
      Object.keys(this.modes).forEach(onModeCheckboxChange);
      var singleLayerMappings = [// checkbox, associated layer
      [this.centers, layers.centers], [this.generalLandUse, layers.generalLandUse]];
      singleLayerMappings.forEach(function (mapping) {
        return _this.wireCheckboxToLayer.apply(_this, _toConsumableArray(mapping));
      });
      this.byPhasing.addEventListener('change', function () {
        if (_this.byPhasing.checked) {
          onPhaseCheckboxChange();
        } else {
          landUseLayers.forEach(function (key) {
            var layer = layers[key];
            layer.setDefinitionExpression(layer.defaultDefinitionExpression);
          });
        }
      });
    },
    wireCheckboxToLayer: function wireCheckboxToLayer(checkbox, layer) {
      console.log('Filter.wirecheckboxToLayer', arguments);
      checkbox.addEventListener('change', function () {
        return layer.setVisibility(checkbox.checked);
      });
    },
    getPhaseQuery: function getPhaseQuery(phaseInfo, checkedPhaseIndexes) {
      // translate the phase info into a definition query taking into account the selected phases
      console.log('Filter.getPhaseQuery');

      var filterPhase = function filterPhase(_, i) {
        return checkedPhaseIndexes.includes(i);
      };

      var joinTxt = ', ';

      var dedup = function dedup(inStatement) {
        return _toConsumableArray(new Set(inStatement.split(joinTxt))).join(joinTxt);
      };

      return "".concat(phaseInfo[0], " IN (").concat(dedup(phaseInfo.slice(1).filter(filterPhase).join(joinTxt)), ")");
    },
    setupParentChildCheckboxes: function setupParentChildCheckboxes() {
      var _this2 = this;

      console.log('Filter.setupParentChildCheckboxes'); // loop through each table looking for multiple checkboxes

      this.domNode.querySelectorAll('table').forEach(function (table) {
        var checkboxes = table.querySelectorAll('input[type="checkbox"]');
        var pauseChildrenChangeEvents = false;

        if (checkboxes.length > 1) {
          var parent = checkboxes[0];
          var children = Array.from(checkboxes).slice(1).filter(function (checkbox) {
            return checkbox !== _this2.byPhasing;
          });
          parent.addEventListener('change', function () {
            pauseChildrenChangeEvents = true;
            children.forEach(function (child) {
              var changed = child.checked !== parent.checked;
              child.checked = parent.checked;

              if (changed) {
                child.dispatchEvent(new Event('change'));
              }
            });
            pauseChildrenChangeEvents = false;
          });
          children.forEach(function (child) {
            child.addEventListener('change', function () {
              if (pauseChildrenChangeEvents) {
                return;
              }

              if (children.every(function (c) {
                return c.checked;
              })) {
                parent.checked = true;
                parent.indeterminate = false;
              } else if (children.some(function (c) {
                return c.checked;
              })) {
                parent.indeterminate = true;
                parent.checked = false;
              } else {
                parent.checked = false;
                parent.indeterminate = false;
              }
            });
          });
        }
      });
    },
    getLayers: function getLayers(layerNames, map) {
      console.log('Filter.getLayers');
      var layerNameLookup = {};
      map.itemInfo.itemData.operationalLayers.forEach(function (layerInfo) {
        layerNameLookup[layerInfo.title] = layerInfo.layerObject;
      });
      var layers = {};
      Object.keys(layerNames).forEach(function (name) {
        var layer = layerNameLookup[layerNames[name]];

        if (!layer) {
          throw new Error("Layer: ".concat(layerNames[name], " not found in web map!"));
        }

        layers[name] = layer;
      });
      return layers;
    }
  });
});
//# sourceMappingURL=Filter.js.map
