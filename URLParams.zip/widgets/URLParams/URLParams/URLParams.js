define(['dijit/_WidgetBase', 'dojo/_base/declare', 'dojo/hash', 'dojo/io-query', 'esri/geometry/Point', 'esri/tasks/query', 'dojo/topic'], function (_WidgetBase, declare, hash, ioQuery, Point, Query, topic) {
  return declare([_WidgetBase], {
    // properties passed in via constructor
    // map: esri/map
    map: null,
    // config: Object
    config: null,
    constructor: function constructor()
    /* props */
    {
      window.URLParams = {};
      this.inherited(arguments);
    },
    postCreate: function postCreate() {
      console.log('URLParams:postCreate', arguments);
      this.initializeRouter();
      this.inherited(arguments);
    },
    initializeRouter: function initializeRouter() {
      var _this = this;

      console.log('URLParams:initializeRouter', arguments);
      var params = ioQuery.queryToObject(hash());

      if (params.guid && params.layerid) {
        var layer = this.map.getLayer(params.layerid);
        var query = new Query();
        query.returnGeometry = true;
        query.where = "GlobalID = '".concat(params.guid, "'");
        layer.selectFeatures(query).then(function (features) {
          if (features.length > 0) {
            var feature = features[0];
            feature.fields = layer.fields;
            feature.displayField = layer.displayField;
            feature.layerID = layer.id; // to be picked up by ProjectInfo widget

            window.URLParams.project = feature;

            _this.map.setExtent(feature.geometry.getExtent(), true);
          }

          _this.wireEvents();
        });
      } else if (params.scale && params.x && params.y) {
        this.map.setScale(parseInt(params.scale, 10));
        this.map.centerAt(new Point({
          x: parseInt(params.x, 10),
          y: parseInt(params.y, 10),
          spatialReference: {
            wkid: this.map.spatialReference.wkid
          }
        })).then(this.wireEvents.bind(this));
      } else {
        this.wireEvents();
      }
    },
    wireEvents: function wireEvents() {
      console.log('URLParams:wireEvents', arguments);
      this.own(this.map.on('extent-change', this.onMapExtentChange.bind(this)), topic.subscribe('url-params-on-project-click', this.setProjectParams.bind(this)), this.map.on('click', this.removeParams.bind(this, ['guid', 'layerid'])));
    },
    onMapExtentChange: function onMapExtentChange(event) {
      console.log('URLParams:onMapExtentChange', arguments);
      var center = event.extent.getCenter();

      if (center.x && center.y) {
        this.setParams({
          x: Math.round(center.x),
          y: Math.round(center.y),
          scale: Math.round(this.map.getScale())
        });
      }
    },
    setProjectParams: function setProjectParams(config) {
      // config contains url and guid
      console.log('URLParams:setProjectParams', arguments);
      this.setParams(config);
      this.removeParams(['x', 'y', 'scale']);
    },
    setParams: function setParams(params) {
      // sets the params in the URL without messing with other ones
      console.log('URLParams:setParams');
      var newParams = Object.assign(ioQuery.queryToObject(hash()), params);
      return hash(ioQuery.objectToQuery(newParams), true);
    },
    removeParams: function removeParams(params) {
      // params: string[]
      console.log('URLParams:removeParams', arguments);
      var newParams = ioQuery.queryToObject(hash());
      params.forEach(function (param) {
        return delete newParams[param];
      });
      return hash(ioQuery.objectToQuery(newParams), true);
    }
  });
});
//# sourceMappingURL=URLParams.js.map
