define({
  "instruction": "创建将在此微件中显示的内容。",
  "defaultContent": "在此添加文本、链接和小图形。",
  "productVersion": "产品版本： ",
  "kernelVersion": "核版本： "
});