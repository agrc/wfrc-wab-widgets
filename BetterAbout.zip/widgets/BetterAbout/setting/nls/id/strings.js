define({
  "instruction": "Buat konten yang ditampilkan dalam widget ini.",
  "defaultContent": "Tambah teks, tautan, dan grafis kecil di sini.",
  "productVersion": "Versi produk: ",
  "kernelVersion": "Versi kernel: "
});