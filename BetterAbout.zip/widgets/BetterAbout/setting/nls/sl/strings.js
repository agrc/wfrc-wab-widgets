define({
  "instruction": "Ustvari vsebino, ki se prikaže v tem pripomočku",
  "defaultContent": "Tukaj dodajte besedilo, povezave in majhne grafike.",
  "productVersion": "Različica produkta: ",
  "kernelVersion": "Različica jedra: "
});