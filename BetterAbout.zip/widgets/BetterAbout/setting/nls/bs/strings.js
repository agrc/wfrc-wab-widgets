define({
  "instruction": "Stvorite sadržaj koji se prikazuje u ovom widgetu.",
  "defaultContent": "Ovdje dodajte tekst, poveznice i male grafičke elemente.",
  "productVersion": "Verzija proizvoda: ",
  "kernelVersion": "Verzija jezgre sustava: "
});