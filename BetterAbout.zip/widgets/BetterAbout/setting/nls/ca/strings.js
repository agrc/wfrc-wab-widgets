define({
  "instruction": "Creeu el contingut que es mostrarà en aquest widget.",
  "defaultContent": "Afegiu text, enllaços i gràfics petits aquí.",
  "productVersion": "Versió del producte: ",
  "kernelVersion": "Versió del nucli: "
});