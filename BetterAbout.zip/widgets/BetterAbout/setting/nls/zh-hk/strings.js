define({
  "instruction": "建立將在此 widget 中顯示的內容。",
  "defaultContent": "在此新增文字、連結和小圖形。",
  "productVersion": "產品版本: ",
  "kernelVersion": "核心版本: "
});