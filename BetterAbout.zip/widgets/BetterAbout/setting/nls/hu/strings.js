define({
  "instruction": "Hozza létre a widgetben megjelenő tartalmat.",
  "defaultContent": "Itt adhatja hozzá a szövegeket, linkeket és kis méretű grafikákat.",
  "productVersion": "Termékverzió: ",
  "kernelVersion": "Kernelverzió: "
});