define({
  "instruction": "Bu araçta görüntülenecek içeriği oluşturun.",
  "defaultContent": "Buraya metin, bağlantılar ve küçük grafikler ekleyin.",
  "productVersion": "Ürün sürümü: ",
  "kernelVersion": "Çekirdek sürümü: "
});