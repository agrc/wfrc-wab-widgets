define(['../About/setting/Setting'], function (Setting) {
  return Setting;
});
//# sourceMappingURL=Setting.js.map
