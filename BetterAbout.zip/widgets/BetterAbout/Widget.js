define(['dojo/_base/declare', './About/Widget', './utilities'], function (declare, About, utilities) {
  return declare([About], {
    constructor: function constructor() {
      console.log('BetterAbout:constructor', arguments);
      this.baseClass = "".concat(this.baseClass, " better-about");
      this.inherited(arguments);
    },
    onOpen: function onOpen() {
      console.log('BetterAbout:onOpen', arguments);
      this.inherited(arguments);
      utilities.dialogitizeImages(this.domNode);
    }
  });
});
//# sourceMappingURL=Widget.js.map
