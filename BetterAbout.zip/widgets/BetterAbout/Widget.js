define(['dojo/_base/declare', './About/Widget', './utilities', 'dojo/topic', 'jimu/PanelManager'], function (declare, About, utilities, topic, PanelManager) {
  var panelManager = PanelManager.getInstance();
  return declare([About], {
    constructor: function constructor() {
      console.log('BetterAbout:constructor', arguments);
      this.baseClass = "".concat(this.baseClass, " better-about");
      this.inherited(arguments);
    },
    onOpen: function onOpen() {
      var _this = this;

      console.log('BetterAbout:onOpen', arguments);
      this.inherited(arguments);
      utilities.dialogitizeImages(this.domNode);

      if (window.URLParams && window.URLParams.infopanel && window.URLParams.infopanel === 'closed') {
        // find panel id of parent panel for this widget
        var id;
        panelManager.panels.forEach(function (panel) {
          if (panel.uri === _this.panel.uri) {
            id = panel.id;
          }
        });

        if (id) {
          panelManager.minimizePanel(id);
          console.log('minimized');
        } else {
          console.error("no matching panel found for ".concat(this.panel.url));
        }
      }
    },
    onMaximize: function onMaximize() {
      console.log('BetterAbout:onMaximize'); // for URLParams widget

      topic.publish('url-params-on-infopanel-open', null);
    },
    onMinimize: function onMinimize() {
      console.log('BetterAbout:onMinimize'); // for URLParams widget

      topic.publish('url-params-on-infopanel-close', null);
    }
  });
});
//# sourceMappingURL=Widget.js.map
