define(['dojo/_base/declare', 'dijit/_TemplatedMixin', 'dijit/_WidgetBase', 'dijit/Dialog', 'dojo/text!./DialogContent.html'], function (declare, _TemplatedMixin, _WidgetBase, Dialog, template) {
  var DialogContent = declare([_WidgetBase, _TemplatedMixin], {
    templateString: template
  });
  return {
    dialogitizeImages: function dialogitizeImages(containerNode) {
      console.log('BetterAbout/utilities:dialogitizeImages', arguments);

      var getShowDialogFunction = function getShowDialogFunction(url) {
        return function () {
          var dialog = new Dialog({
            closable: true,
            content: new DialogContent({
              url: url,
              closeDialog: function closeDialog() {
                return dialog.destroy();
              }
            }),
            draggable: false,
            baseClass: 'better-about-dialog',
            onShow: function onShow() {
              // give the underlay time to be built
              window.setTimeout(function () {
                document.getElementById("".concat(dialog.id, "_underlay")).addEventListener('click', function () {
                  dialog.destroy();
                });
              });
            }
          });
          dialog.show();
        };
      };

      Array.from(containerNode.getElementsByTagName('img')).forEach(function (img) {
        img.addEventListener('click', getShowDialogFunction(img.src));
      });
    }
  };
});
//# sourceMappingURL=utilities.js.map
