define({
  "productVersion": "รุ่นผลิตภัณฑ์: ",
  "kernelVersion": "เวอร์ชันเคอแนล: ",
  "_widgetLabel": "เกี่ยวกับ"
});