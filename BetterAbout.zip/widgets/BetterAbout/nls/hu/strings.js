define({
  "productVersion": "Termékverzió: ",
  "kernelVersion": "Kernelverzió: ",
  "_widgetLabel": "További információ"
});