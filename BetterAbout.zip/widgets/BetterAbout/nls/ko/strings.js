define({
  "productVersion": "제품 버전: ",
  "kernelVersion": "커널 버전: ",
  "_widgetLabel": "정보"
});