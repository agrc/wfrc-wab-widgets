define({
  "productVersion": "Wersja produktu: ",
  "kernelVersion": "Wersja jądra systemu: ",
  "_widgetLabel": "Informacje o"
});