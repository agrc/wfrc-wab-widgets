define({
  "productVersion": "Versió del producte: ",
  "kernelVersion": "Versió del nucli: ",
  "_widgetLabel": "Quant a"
});