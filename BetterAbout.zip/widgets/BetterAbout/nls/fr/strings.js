define({
  "productVersion": "Version du produit : ",
  "kernelVersion": "Version du noyau : ",
  "_widgetLabel": "A propos"
});