define({
  "productVersion": "Produktversjon: ",
  "kernelVersion": "Kjerneversjon: ",
  "_widgetLabel": "Om"
});