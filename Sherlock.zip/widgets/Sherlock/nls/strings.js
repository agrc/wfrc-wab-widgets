define({
  root: {
    _widgetLabel: 'Sherlock',
    widgetTitle: 'Sherlock',
    description: 'A WAB wrapper around AGRC&#39;s sherlock widget.'
  }
  // add supported locales below:
  // , "zh-cn": true
});
