define(['dojo/_base/declare', 'jimu/BaseWidget', './ProjectInfo/ProjectInfo'], function (declare, BaseWidget, ProjectInfo) {
  return declare([BaseWidget], {
    mainWidget: null,

    postCreate: function postCreate() {
      this.mainWidget = new ProjectInfo({
        config: this.config,
        map: this.map
      }, this.widgetContainer);
    }
  });
});
