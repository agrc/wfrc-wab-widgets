define(['dojo/_base/declare', 'jimu/BaseWidget', './ProjectInfo/ProjectInfo'], function (declare, BaseWidget, ProjectInfo) {
  return declare([BaseWidget], {
    mainWidget: null,

    postCreate: function postCreate() {
      this.mainWidget = new ProjectInfo({
        config: this.config,
        map: this.map
      }, this.widgetContainer);
    }
  }
  // startup() {
  //   this.inherited(arguments);
  //   console.log('ProjectInfo::startup');
  // },
  // onOpen() {
  //   console.log('ProjectInfo::onOpen');
  // },
  // onClose(){
  //   console.log('ProjectInfo::onClose');
  // },
  // onMinimize(){
  //   console.log('ProjectInfo::onMinimize');
  // },
  // onMaximize(){
  //   console.log('ProjectInfo::onMaximize');
  // },
  // onSignIn(credential){
  //   console.log('ProjectInfo::onSignIn', credential);
  // },
  // onSignOut(){
  //   console.log('ProjectInfo::onSignOut');
  // }
  // onPositionChange(){
  //   console.log('ProjectInfo::onPositionChange');
  // },
  // resize(){
  //   console.log('ProjectInfo::resize');
  // }
  );
});
