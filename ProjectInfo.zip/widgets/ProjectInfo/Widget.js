define(['dojo/_base/declare', 'jimu/BaseWidget', './ProjectInfo/ProjectInfo', 'jimu/PanelManager'], function (declare, BaseWidget, ProjectInfo, PanelManager) {
  return declare([BaseWidget], {
    mainWidget: null,
    postCreate: function postCreate() {
      this.mainWidget = new ProjectInfo({
        config: this.config,
        map: this.map
      }, this.widgetContainer);
      this.map.on('click', this.onMapClick.bind(this));
    },
    onMapClick: function onMapClick() {
      var _this = this;

      // auto-open this widget's panel and close all others except BetterAbout
      var panelManager = PanelManager.getInstance();
      panelManager.panels.forEach(function (panel) {
        if (panel.config.id === _this.id) {
          if (panel.state === 'closed') {
            panelManager.openPanel(panel);
          }
        } else if (panel.windowState !== 'maximized') {
          panelManager.closePanel(panel);
        }
      });
    }
  });
});
//# sourceMappingURL=Widget.js.map
