define([], function () {
  return {
    GLOBALID_FIELD_NAME: 'GlobalID'
  };
});
