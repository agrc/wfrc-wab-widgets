define([], function () {
  return {
    GLOBALID_FIELD_NAME: 'GlobalID'
  };
});
//# sourceMappingURL=Constants.js.map
