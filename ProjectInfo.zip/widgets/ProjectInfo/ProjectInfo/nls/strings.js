define({
  root: {
    _widgetLabel: 'Project Info',
    widgetTitle: 'Project Info',
    description: 'A identify widget for displaying basic information about a project or projects.',
    instructions: 'Click on a project on the map to view information and leave comments.'
  },
  es: true
});
