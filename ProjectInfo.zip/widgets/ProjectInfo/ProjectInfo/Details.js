define(['dijit/_TemplatedMixin', 'dijit/_WidgetBase', 'dojo/fx', 'dojo/_base/declare', 'dojo/dom-construct', 'dojo/text!./Details.html'], function (_TemplatedMixin, _WidgetBase, coreFx, declare, domConstruct, template) {
  var _slicedToArray = function () {
    function sliceIterator(arr, i) {
      var _arr = [];
      var _n = true;
      var _d = false;
      var _e = undefined;

      try {
        for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
          _arr.push(_s.value);

          if (i && _arr.length === i) break;
        }
      } catch (err) {
        _d = true;
        _e = err;
      } finally {
        try {
          if (!_n && _i["return"]) _i["return"]();
        } finally {
          if (_d) throw _e;
        }
      }

      return _arr;
    }

    return function (arr, i) {
      if (Array.isArray(arr)) {
        return arr;
      } else if (Symbol.iterator in Object(arr)) {
        return sliceIterator(arr, i);
      } else {
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
      }
    };
  }();

  return declare([_WidgetBase, _TemplatedMixin], {
    baseClass: 'details',
    templateString: template,
    open: false,
    aliasValuePairs: null,

    // properties passed in via the constructor
    // feature: Object
    //      esri feature object
    feature: null,

    // fields: Object[]
    //      array of field objects from FeatureLayer.fields
    fields: null,

    // displayField: String
    //      the name of the field to use as the title
    displayField: null,

    // config: Object
    config: null,

    constructor: function constructor(props) {
      console.log('Details:constructor', arguments);

      Object.assign(this, props.feature.attributes);

      this.title = props.feature.attributes[props.displayField];

      this.aliasValuePairs = this.getAliasValuePairs(props.feature.attributes, props.fields, props.config.excludeFields, props.displayField);

      this.inherited(arguments);
    },
    getAliasValuePairs: function getAliasValuePairs(attributes, fields, excludeFields, displayField) {
      console.log('Details:getAliasValuePairs', arguments);

      var aliasLookup = {};
      fields.forEach(function (field) {
        aliasLookup[field.name] = field.alias;
      });

      return Object.keys(attributes).filter(function (fieldName) {
        return !excludeFields.concat([displayField]).includes(fieldName);
      }).map(function (fieldName) {
        return [aliasLookup[fieldName], attributes[fieldName]];
      });
    },
    postCreate: function postCreate() {
      var _this = this;

      console.log('Details:postCreate', arguments);

      this.aliasValuePairs.forEach(function (_ref) {
        var _ref2 = _slicedToArray(_ref, 2),
            alias = _ref2[0],
            value = _ref2[1];

        var tr = domConstruct.create('tr', {}, _this.table);
        domConstruct.create('td', {
          innerHTML: alias,
          className: 'alias'
        }, tr);
        domConstruct.create('td', {
          innerHTML: value,
          className: 'value'
        }, tr);
      });

      this.inherited(arguments);
    },
    onTitleClick: function onTitleClick() {
      console.log('Details:onTitleClick', arguments);

      if (this.open) {
        coreFx.wipeOut({ node: this.body }).play();
      } else {
        coreFx.wipeIn({ node: this.body }).play();
      }

      this.open = !this.open;
    }
  });
});
