define(['dijit/_TemplatedMixin', 'dijit/_WidgetBase', './Constants', './Comments', 'dojo/fx', 'dojo/_base/declare', 'dojo/dom-construct', 'esri/symbols/SimpleFillSymbol', 'esri/symbols/SimpleLineSymbol', 'esri/symbols/SimpleMarkerSymbol', 'dojo/text!./Details.html', 'dojo/topic'], function (_TemplatedMixin, _WidgetBase, _Constants, Comments, coreFx, declare, domConstruct, SimpleFillSymbol, SimpleLineSymbol, SimpleMarkerSymbol, template, topic) {
  var GLOBALID_FIELD_NAME = _Constants.GLOBALID_FIELD_NAME;

  var _slicedToArray = function () {
    function sliceIterator(arr, i) {
      var _arr = [];
      var _n = true;
      var _d = false;
      var _e = undefined;

      try {
        for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
          _arr.push(_s.value);

          if (i && _arr.length === i) break;
        }
      } catch (err) {
        _d = true;
        _e = err;
      } finally {
        try {
          if (!_n && _i["return"]) _i["return"]();
        } finally {
          if (_d) throw _e;
        }
      }

      return _arr;
    }

    return function (arr, i) {
      if (Array.isArray(arr)) {
        return arr;
      } else if (Symbol.iterator in Object(arr)) {
        return sliceIterator(arr, i);
      } else {
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
      }
    };
  }();

  return declare([_WidgetBase, _TemplatedMixin], {
    baseClass: 'details',
    templateString: template,
    open: false,
    aliasValuePairs: null,
    selectionSymbols: null,
    originalSymbol: null,
    commentsShown: false,

    // properties passed in via the constructor
    // feature: Object
    //      esri feature object
    feature: null,

    // fields: Object[]
    //      array of field objects from FeatureLayer.fields
    fields: null,

    // displayField: String
    //      the name of the field to use as the title
    displayField: null,

    // layerID: String
    //    the id of the parent layer for this feature.
    //    used by URLParams
    layerID: null,

    // config: Object
    config: null,

    // nls: Object
    //      language strings
    nls: null,

    constructor: function constructor(props) {
      console.log('Details:constructor', arguments);

      Object.assign(this, props.feature.attributes);

      this.title = props.feature.attributes[props.displayField];

      this.aliasValuePairs = this.getAliasValuePairs(props.feature.attributes, props.fields, props.config.excludeFields, props.displayField);

      this.originalSymbol = props.feature.symbol;

      this.inherited(arguments);
    },
    postMixInProperties: function postMixInProperties() {
      console.log('Details:postMixInProperties', arguments);

      this.selectionSymbols = {
        point: new SimpleMarkerSymbol({
          color: this.config.selectionColor
        }),
        polyline: new SimpleLineSymbol({
          color: this.config.selectionColor,
          width: 6,
          style: 'esriSLSSolid',
          type: 'esriSLS'
        }),
        polygon: new SimpleFillSymbol({
          type: 'esriSFS',
          style: 'esriSFSSolid',
          color: this.config.selectionColor
        })
      };
    },
    getAliasValuePairs: function getAliasValuePairs(attributes, fields, excludeFields, displayField) {
      console.log('Details:getAliasValuePairs', arguments);

      var aliasLookup = {};
      fields.forEach(function (field) {
        aliasLookup[field.name] = field.alias;
      });

      return Object.keys(attributes).filter(function (fieldName) {
        return !excludeFields.concat([displayField]).includes(fieldName);
      }).map(function (fieldName) {
        return [aliasLookup[fieldName], attributes[fieldName]];
      });
    },
    postCreate: function postCreate() {
      var _this = this;

      console.log('Details:postCreate', arguments);

      this.aliasValuePairs.forEach(function (_ref) {
        var _ref2 = _slicedToArray(_ref, 2),
            alias = _ref2[0],
            value = _ref2[1];

        var tr = domConstruct.create('tr', {}, _this.table);
        domConstruct.create('td', {
          innerHTML: alias,
          className: 'alias'
        }, tr);
        domConstruct.create('td', {
          innerHTML: value,
          className: 'value'
        }, tr);
      });

      this.inherited(arguments);
    },
    shouldDisplayComments: function shouldDisplayComments(fields) {
      console.log('Details:shouldDisplayComments', arguments);

      return this.config.commentsEnabled && fields.some(function (fieldInfo) {
        return fieldInfo.name === GLOBALID_FIELD_NAME;
      });
    },
    onTitleEnter: function onTitleEnter() {
      console.log('Details:onTitleEnter', arguments);

      this.highlight();
    },
    highlight: function highlight() {
      console.log('Details:highlight', arguments);

      this.feature.setSymbol(this.selectionSymbols[this.feature.geometry.type]);
    },
    onTitleLeave: function onTitleLeave() {
      console.log('Details:onTitleLeave', arguments);

      if (!this.open) {
        this.feature.setSymbol(this.originalSymbol);
      }
    },
    expand: function expand() {
      console.log('Details:expand', arguments);

      if (this.shouldDisplayComments(this.fields) && !this.commentsShown) {
        this.own(new Comments({
          globalid: this.feature.attributes[GLOBALID_FIELD_NAME],
          config: this.config,
          nls: this.nls
        }, this.commentsContainer));

        this.commentsShown = true;
      }

      coreFx.wipeIn({ node: this.body }).play();

      // this topic name needs to match what's in URLParams.js
      topic.publish('url-params-on-project-click', {
        guid: this.feature.attributes[GLOBALID_FIELD_NAME],
        layerid: this.layerID
      });
    },
    onTitleClick: function onTitleClick() {
      console.log('Details:onTitleClick', arguments);

      if (this.open) {
        coreFx.wipeOut({ node: this.body }).play();
      } else {
        this.expand();
      }

      this.open = !this.open;
    },
    destroy: function destroy() {
      console.log('Details:destroy', arguments);

      this.feature.setSymbol(this.originalSymbol);

      this.inherited(arguments);
    }
  });
});
