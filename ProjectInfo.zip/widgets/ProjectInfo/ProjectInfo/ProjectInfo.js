define(['dijit/_TemplatedMixin', 'dijit/_WidgetBase', 'dojo/_base/declare', './Details', 'dojo/dom-construct', 'esri/tasks/query', 'esri/symbols/SimpleLineSymbol', 'esri/symbols/SimpleMarkerSymbol', 'esri/symbols/SimpleFillSymbol', 'dojo/i18n!./nls/strings', 'dojo/text!./ProjectInfo.html'], function (_TemplatedMixin, _WidgetBase, declare, Details, domConstruct, Query, SimpleLineSymbol, SimpleMarkerSymbol, SimpleFillSymbol, strings, template) {
  return declare([_WidgetBase, _TemplatedMixin], {
    baseClass: 'project-info',
    templateString: template,
    featureLayers: null,
    selectionSymbols: null,

    postMixInProperties: function postMixInProperties() {
      this.nls = strings;

      this.selectionSymbols = {
        esriGeometryPoint: new SimpleMarkerSymbol({
          color: this.config.selectionColor
        }),
        esriGeometryPolyline: new SimpleLineSymbol({
          color: this.config.selectionColor,
          width: 6,
          style: 'esriSLSSolid',
          type: 'esriSLS'
        }),
        esriGeometryPolygon: new SimpleFillSymbol({
          type: 'esriSFS',
          style: 'esriSFSSolid',
          color: this.config.selectionColor
        })
      };

      this.inherited(arguments);
    },
    postCreate: function postCreate() {
      var _this = this;

      console.log('ProjectInfo.postCreate');

      this.featureLayers = this.map.graphicsLayerIds.map(function (id) {
        return _this.map.getLayer(id);
      }).filter(function (layer) {
        return layer.url;
      });

      this.featureLayers.forEach(function (layer) {
        return layer.setSelectionSymbol(_this.selectionSymbols[layer.geometryType]);
      });

      this.own(this.map.on('click', this.onMapClick.bind(this)));
    },
    onMapClick: function onMapClick(clickEvent) {
      var _this2 = this;

      console.log('ProjectInfo.onMapClick', clickEvent);

      this.instructions.className = 'hidden';

      var query = new Query();
      query.geometry = clickEvent.mapPoint;
      query.distance = this.getTolerance(this.config.clickPixelTolerance);
      query.units = 'meters';

      // return function that adds the fields and displayField properties
      // to the feature objects for use in the Details Widget
      var getAddMetaToFeatureFunction = function getAddMetaToFeatureFunction(layer) {
        return function (featureSet) {
          return featureSet.map(function (feature) {
            feature.fields = layer.fields;
            feature.displayField = layer.displayField;

            return feature;
          });
        };
      };

      // query all feature layers and then flatten into a single array of features
      Promise.all(this.featureLayers.map(function (layer) {
        return layer.selectFeatures(query).then(getAddMetaToFeatureFunction(layer));
      })).then(function (featureSets) {
        return _this2.setFeatures(featureSets.flat());
      });
    },
    getTolerance: function getTolerance(pixelTolerance) {
      console.log('ProjectInfo:getTolerance', arguments);

      var pixelWidth = this.map.extent.getWidth() / this.map.width;

      return pixelTolerance * pixelWidth;
    },
    setFeatures: function setFeatures(features) {
      var _this3 = this;

      console.log('ProjectInfo:setFeatures', arguments);

      if (this.detailsWidgets) {
        this.detailsWidgets.forEach(function (widget) {
          return widget.destroy();
        });
        this.detailsWidgets = null;
      }

      if (features.length > 0) {
        this.detailsWidgets = features.map(function (feature) {
          return new Details({
            feature: feature,
            fields: feature.fields,
            displayField: feature.displayField,
            config: _this3.config
          }, domConstruct.create('div', {}, _this3.detailsContainer));
        });
      } else {
        this.instructions.className = '';
      }
    }
  });
});
