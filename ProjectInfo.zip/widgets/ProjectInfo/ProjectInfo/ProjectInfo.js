define(['dijit/_TemplatedMixin', 'dijit/_WidgetBase', 'dojo/_base/declare', './Details', 'dojo/dom-construct', 'esri/tasks/query', 'dojo/text!./ProjectInfo.html'], function (_TemplatedMixin, _WidgetBase, declare, Details, domConstruct, Query, template) {
  return declare([_WidgetBase, _TemplatedMixin], {
    baseClass: 'project-info',
    templateString: template,
    featureLayers: null,
    postMixInProperties: function postMixInProperties() {
      console.log('ProjectInfo:postMixInProperties', arguments);
      this.nls = this.config.strings[this.config.language];
      this.inherited(arguments);
    },
    postCreate: function postCreate() {
      var _this = this;

      console.log('ProjectInfo.postCreate');
      this.featureLayers = this.map.graphicsLayerIds.map(function (id) {
        return _this.map.getLayer(id);
      }).filter(function (layer) {
        return layer.url;
      });
      this.own(this.map.on('click', this.onMapClick.bind(this)));

      if (window.URLParams && window.URLParams.project) {
        this.setFeatures([window.URLParams.project]);
      }
    },
    onMapClick: function onMapClick(clickEvent) {
      var _this2 = this;

      console.log('ProjectInfo.onMapClick', clickEvent);
      var query = new Query();
      query.geometry = clickEvent.mapPoint;
      query.distance = this.getTolerance(this.config.clickPixelTolerance);
      query.units = 'meters'; // return function that adds the fields and displayField properties
      // to the feature objects for use in the Details Widget

      var getAddMetaToFeatureFunction = function getAddMetaToFeatureFunction(layer) {
        return function (featureSet) {
          return featureSet.map(function (feature) {
            feature.fields = layer.fields;
            feature.displayField = layer.displayField;
            feature.layerID = layer.id;
            feature.layerName = layer.name;
            return feature;
          });
        };
      }; // query all feature layers and then flatten into a single array of features


      Promise.all(this.featureLayers.map(function (layer) {
        return layer.selectFeatures(query).then(getAddMetaToFeatureFunction(layer));
      })).then(function (featureSets) {
        return _this2.setFeatures(featureSets.reduce(function (acc, val) {
          return acc.concat(val);
        }, []));
      });
    },
    getTolerance: function getTolerance(pixelTolerance) {
      console.log('ProjectInfo:getTolerance', arguments);
      var pixelWidth = this.map.extent.getWidth() / this.map.width;
      return pixelTolerance * pixelWidth;
    },
    setFeatures: function setFeatures(features) {
      var _this3 = this;

      console.log('ProjectInfo:setFeatures', arguments);
      features = this.sortFeatures(features);

      if (this.detailsWidgets) {
        this.detailsWidgets.forEach(function (widget) {
          return widget.destroy();
        });
        this.detailsWidgets = null;
      }

      if (features.length > 0) {
        this.instructions.className = 'hidden';
        this.detailsWidgets = features.map(function (feature) {
          return new Details({
            feature: feature,
            fields: feature.fields,
            displayField: feature.displayField,
            layerID: feature.layerID,
            config: _this3.config,
            nls: _this3.nls
          }, domConstruct.create('div', {}, _this3.detailsContainer));
        }); // if there's only one feature then set it to open automatically

        if (features.length === 1) {
          this.detailsWidgets[0].expand();
          this.detailsWidgets[0].highlight();
        }
      } else {
        this.instructions.className = '';
      }
    },
    sortFeatures: function sortFeatures(features) {
      // sorts the features according to the featureLayerOrder in the config
      console.log('ProjectInfo:sortFeatures', arguments);
      var order = this.config.layerSortOrder;
      return features.sort(function (first, second) {
        var firstIndex = order.indexOf(first.layerName);
        var secondIndex = order.indexOf(second.layerName);

        if (firstIndex < secondIndex) {
          return -1;
        } else if (firstIndex === secondIndex) {
          return 0;
        }

        return 1;
      });
    }
  });
});
//# sourceMappingURL=ProjectInfo.js.map
