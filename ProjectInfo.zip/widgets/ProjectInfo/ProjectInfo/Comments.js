define(['dijit/_TemplatedMixin', 'dijit/_WidgetBase', 'dojo/fx', 'dojo/_base/declare', 'dojo/dom-construct', 'esri/request', './ExistingComment', 'dojo/text!./Comments.html'], function (_TemplatedMixin, _WidgetBase, coreFx, declare, domConstruct, esriRequest, ExistingComment, template) {
  return declare([_WidgetBase, _TemplatedMixin], {
    baseClass: 'comments',
    templateString: template,
    newCommentFormOpen: false,
    // properties passed in via constructor
    // globalid: string
    //      the globalid of the feature that the comments are related to
    globalid: null,
    // config: object
    //      the config object from config.json
    config: null,
    // nls: Object
    //      language strings
    nls: null,
    constructor: function constructor() {
      console.log('Comments:constructor', arguments);
    },
    postCreate: function postCreate() {
      var _this = this;

      console.log('Comments:postCreate', arguments);
      this.getInputs().forEach(function (input) {
        input.addEventListener('input', _this.updateCharCount.bind(_this));
        input.parentElement.getElementsByTagName('span')[0].textContent = input.maxLength;
      });
      this.loadExistingComments();
      this.inherited(arguments);
    },
    loadExistingComments: function loadExistingComments() {
      var _this2 = this;

      console.log('Comments:loadExistingComments', arguments);

      var onSuccess = function onSuccess(response) {
        response.features // show newest comments first
        .sort(function (feature1, feature2) {
          return feature1.attributes.CommentDT < feature2.attributes.CommentDT ? 1 : -1;
        }).forEach(function (feature) {
          return _this2.addComment(feature.attributes);
        });
        _this2.numComments.textContent = response.features.length;
      };

      var onFailure = function onFailure(error) {
        _this2.loadExistingErrorMessage.textContent = "Failed to load existing comments: ".concat(error.message);
      };

      esriRequest({
        url: "".concat(this.config.commentsTableUrl, "/query"),
        content: {
          f: 'json',
          where: "GUID = '".concat(this.globalid, "'"),
          outFields: '*'
        },
        handleAs: 'json'
      }).then(onSuccess, onFailure);
    },
    addComment: function addComment(attributes) {
      var top = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      console.log('Comments:addComment', arguments);
      var existingComment = new ExistingComment(attributes, domConstruct.create('div', {}, this.commentsContainer, top ? 'first' : 'last'));
      existingComment.startup();
      this.own(existingComment);
      this.numComments.textContent = parseInt(this.numComments.textContent, 10) + 1;
    },
    getInputs: function getInputs() {
      console.log('Details:getInputs', arguments);
      var inputs = Array.from(this.newCommentForm.getElementsByTagName('input'));
      var textarea = Array.from(this.newCommentForm.getElementsByTagName('textarea'));
      return inputs.concat(textarea);
    },
    updateCharCount: function updateCharCount(event) {
      console.log('Comments:updateCharCount', arguments);
      var input = event.target;
      var span = input.parentElement.getElementsByTagName('span')[0];
      span.textContent = parseInt(input.maxLength, 10) - input.value.length;
      this.submitBtn.disabled = this.Comment.value.length === 0;
    },
    toggleNewCommentForm: function toggleNewCommentForm() {
      console.log('Comments:toggleNewCommentForm', arguments);

      if (this.newCommentFormOpen) {
        coreFx.wipeOut({
          node: this.newCommentForm
        }).play();
      } else {
        coreFx.wipeIn({
          node: this.newCommentForm
        }).play();
      }

      this.newCommentFormOpen = !this.newCommentFormOpen;
    },
    toggleExistingComments: function toggleExistingComments(event) {
      console.log('Comment:toggleExistingComments', arguments);

      if (event.target.textContent === this.nls.show) {
        coreFx.wipeIn({
          node: this.commentsContainer
        }).play();
        event.target.textContent = this.nls.hide;
      } else {
        coreFx.wipeOut({
          node: this.commentsContainer
        }).play();
        event.target.textContent = this.nls.show;
      }
    },
    submitComment: function submitComment() {
      var _this3 = this;

      console.log('Comments:submitComment', arguments);
      this.submitErrorMessage.textContent = '';
      var attributes = {
        CommentDT: new Date(),
        GUID: this.globalid
      };
      this.getInputs().forEach(function (input) {
        attributes[input.dataset.dojoAttachPoint] = input.value;
      });

      var onSuccess = function onSuccess(response) {
        var result = response.addResults[0];

        if (result.success) {
          _this3.addComment(attributes, true);

          _this3.clearForm();
        } else {
          _this3.onFailure({
            message: result.error.description
          });
        }
      };

      var onFailure = function onFailure(error) {
        _this3.submitErrorMessage.textContent = error.message;
      };

      esriRequest({
        url: "".concat(this.config.commentsTableUrl, "/addFeatures"),
        content: {
          f: 'json',
          features: JSON.stringify([{
            attributes: attributes
          }])
        },
        handleAs: 'json'
      }, {
        usePost: true
      }).then(onSuccess, onFailure);
    },
    clearForm: function clearForm() {
      console.log('Comments:clearForm', arguments);
      this.getInputs().forEach(function (input) {
        input.value = '';
        input.dispatchEvent(new Event('input'));
      });
      this.toggleNewCommentForm();
    }
  });
});
//# sourceMappingURL=Comments.js.map
