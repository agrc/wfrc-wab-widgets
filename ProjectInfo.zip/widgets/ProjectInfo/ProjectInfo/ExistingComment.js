define(['dijit/_TemplatedMixin', 'dijit/_WidgetBase', 'dojo/_base/declare', 'dojo/text!./ExistingComment.html'], function (_TemplatedMixin, _WidgetBase, declare, template) {
  return declare([_WidgetBase, _TemplatedMixin], {
    templateString: template,

    constructor: function constructor(props) {
      console.log('ExistingComment:constructor', arguments);

      this.prettyDate = new Date(props.CommentDT).toLocaleString();
    }
  });
});
