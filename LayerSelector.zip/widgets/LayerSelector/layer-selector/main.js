define([
    './LayerSelector'
], function (
    LayerSelector
) {
    return LayerSelector;
});
