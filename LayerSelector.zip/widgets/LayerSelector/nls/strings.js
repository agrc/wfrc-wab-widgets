define({
  root: {
    _widgetLabel: 'Layer Selector',
    widgetTitle: 'Layer Selector',
    description: 'A WAB wrapper around AGRC&#39;s layer-selector widget.'
  }
  // add supported locales below:
  // , "zh-cn": true
});
