define(['dojo/_base/declare', 'jimu/BaseWidget', './layer-selector/LayerSelector', './utilities'], function (declare, BaseWidget, LayerSelector, _utilities) {
  var applyFactories = _utilities.applyFactories;
  return declare([BaseWidget], {
    mainWidget: null,

    postCreate: function postCreate() {
      console.log('LayerSelector:postCreate');

      this.config = applyFactories(this.config);

      this.mainWidget = new LayerSelector(Object.assign({
        map: this.map
      }, this.config));
      this.mainWidget.startup();
    }
  });
});
