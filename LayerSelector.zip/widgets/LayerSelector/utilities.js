define(['esri/layers/ArcGISDynamicMapServiceLayer', 'esri/layers/ArcGISImageServiceLayer', 'esri/layers/ArcGISTiledMapServiceLayer', 'esri/layers/FeatureLayer', 'esri/layers/KMLLayer', 'esri/layers/LabelLayer', 'esri/layers/RasterLayer', 'esri/layers/StreamLayer', 'esri/layers/TiledMapServiceLayer', 'esri/layers/VectorTileLayer', 'esri/layers/WCSLayer', 'esri/layers/WebTiledLayer', 'esri/layers/WFSLayer', 'esri/layers/WMSLayer', 'esri/layers/WMTSLayer'], function (ArcGISDynamicMapServiceLayer, ArcGISImageServiceLayer, ArcGISTiledMapServiceLayer, FeatureLayer, KMLLayer, LabelLayer, RasterLayer, StreamLayer, TiledMapServiceLayer, VectorTileLayer, WCSLayer, WebTiledLayer, WFSLayer, WMSLayer, WMTSLayer) {
  var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
    return typeof obj;
  } : function (obj) {
    return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
  };

  var factoryLookup = {
    ArcGISDynamicMapServiceLayer: ArcGISDynamicMapServiceLayer,
    ArcGISImageServiceLayer: ArcGISImageServiceLayer,
    ArcGISTiledMapServiceLayer: ArcGISTiledMapServiceLayer,
    FeatureLayer: FeatureLayer,
    KMLLayer: KMLLayer,
    LabelLayer: LabelLayer,
    RasterLayer: RasterLayer,
    StreamLayer: StreamLayer,
    TiledMapServiceLayer: TiledMapServiceLayer,
    VectorTileLayer: VectorTileLayer,
    WCSLayer: WCSLayer,
    WebTiledLayer: WebTiledLayer,
    WFSLayer: WFSLayer,
    WMSLayer: WMSLayer,
    WMTSLayer: WMTSLayer
  };

  return {
    applyFactories: function applyFactories(config) {
      console.log('LayerSelector:utilities:applyFactories');

      var convert = function convert(layer) {
        if ((typeof layer === 'undefined' ? 'undefined' : _typeof(layer)) === String) {
          return layer;
        }

        return Object.assign(layer, {
          Factory: factoryLookup[layer.Factory]
        });
      };

      var baseLayers = Array.from(config.baseLayers);
      config.baseLayers = baseLayers.map(convert);

      var overlays = Array.from(config.overlays);
      config.overlays = overlays.map(convert);

      return config;
    }
  };
});
